<?php
// 直接跳转到管理员登录页面
header('Location: admin_login.php');
exit;
?>